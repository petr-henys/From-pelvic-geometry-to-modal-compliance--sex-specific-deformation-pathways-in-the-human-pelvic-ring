29 September 2026

Editors-in-Chief

*Biomechanics and Modeling in Mechanobiology*

Dear Editors,

Please consider our manuscript, “Comparing deformation subspaces across anatomical variability: a population finite-element study of the human pelvis,” for publication as an Original Article in *Biomechanics and Modeling in Mechanobiology*.

Population finite-element studies require comparable mechanical descriptors across anatomically different subjects. Eigenvalue rank is convenient, but neighbouring modes can exchange their correspondence to anatomical deformation patterns. A rank-based comparison may consequently suggest a large change in anatomical coupling even when the relevant modal subspace retains similar deformation capacity.

We investigate this problem in 278 CT-derived pelvic finite-element models using a common reference domain, spectral gap analysis, modal assignment, principal angles, basis-invariant anatomical functionals, and static modal energy decomposition. Low-rank modes retain stable ordering, whereas a recurrent rank 9--10 block occurs in 54.7% of subjects. Within this block, median anteroposterior inlet coupling at rank 9 differs by approximately 69% between subjects without and with label exchange; the corresponding subspace capacity differs by approximately 5%. Standing and internal-ring expansion loads recruit different spectral regions, connecting the comparison framework to controlled pelvic loading.

Building on earlier pelvic spectral metrics and established subspace methods, this study quantifies how mode correspondence changes anatomical interpretation across a pelvic population. The combination of computational solid mechanics and anatomically defined subspace measures aligns with the journal's scope.

The analysis reports kinematic capacity and load-dependent recruitment separately. The expansion cases compare linear pelvic responses to prescribed tractions, and a constructed analytical example illustrates the spectral mechanism. The mathematical formulation, results, figures, tables, and validation checks are included in the manuscript, with extended analyses in appendices within the same article.

The source anatomical dataset is cited separately from the present analysis. Summary results are supplied within the manuscript; a public archive of the custom code and additional derived outputs has not yet been established, as stated in the availability declarations.

Thank you for considering our manuscript.

Sincerely,

Niels Hammer, on behalf of the authors

Division of Macroscopic and Clinical Anatomy

Medical University of Graz, Austria

niels.hammer@medunigraz.at
