29 September 2026

Editors-in-Chief

*Biomechanics and Modeling in Mechanobiology*

Dear Editors,

Please consider our manuscript, “Comparing deformation subspaces across anatomical variability: a population finite-element study of the human pelvis,” as an Original Article in *Biomechanics and Modeling in Mechanobiology*.

Population finite-element studies often compare deformation modes by eigenvalue rank. That comparison can be misleading when neighbouring modes exchange their anatomical roles. In 278 CT-derived pelvic models, we found a recurrent rank 9–10 cluster in 54.7% of subjects. Between subjects with and without label exchange, the median inlet coupling at rank 9 differed by approximately 69%, while the capacity of the two-mode subspace differed by approximately 5%. The apparent rank-level change therefore substantially overstates the change in this anatomical response.

The anatomical diameter measures give this distinction biological meaning: they show whether variation between pelves changes the ring's capacity to alter canal dimensions or merely shifts that response between neighbouring modes. Standing and pelvic expansion loads recruit different spectral regions, linking the available deformation patterns to how the ring responds under specified loads. The study therefore connects population variation in pelvic anatomy with mechanically interpretable function, a central concern for the journal's readership.

Thank you for considering our manuscript.

Sincerely,

Niels Hammer, on behalf of the authors

Division of Macroscopic and Clinical Anatomy

Medical University of Graz, Austria

niels.hammer@medunigraz.at
